import logging
from functools import partial
from timeit import default_timer as time

import pandas as pd
from sqlalchemy import create_engine

from ilf_scripts.utils.data_utils.clusterer import clusterer
from ilf_scripts.utils.data_utils.db_calls import etl_query, data_upload
from ilf_scripts.utils.data_utils.mk_features import get_features
from ilf_scripts.utils.data_utils.preproc import drop_zeros, fill_max_min, \
    fill_zeros

# Set the module wide logger
log = logging.getLogger('ilf')
log.setLevel(logging.DEBUG)


def etl(store, num_tasks=100, query=None):
    # Create an engine to use throughout the module, note: This does NOT
    # establish a connection, it will only do so when .connect() or .execute()
    # are called.
    engine = create_engine('postgres://ilf@10.133.1.18:5432/ilf')

    # Start a timer for the entire module
    mod_start = time()

    start = time()
    # Query the data base for the store
    log.debug("Pulling data for ETL process")
    df = etl_query(store, engine)

    log.debug("Pulling data took: %s", str(time() - start))

    df_nz = df.copy()

    df_nz = df_nz[df_nz.sls_qty > 0]

    log.debug("Dropping items whose max value is <= 0")
    df = df.groupby(['itm_id'], as_index=False) \
        .apply(drop_zeros) \
        .reset_index(drop=True)

    # Get the minimum and maximum date from the entire DataFrame
    min_dt = df['dt'].min()
    max_dt = df['dt'].max()

    # Create a DatatimeIndex using the min and max date
    date_list = pd.date_range(min_dt,
                              periods=(max_dt - min_dt).days // 7 + 1,
                              freq='W-MON') \
        .to_series(name='dt') \
        .reset_index(drop=True)

    start = time()
    log.debug("Started to fill missing data with 0's")
    # Partially fill the functions with data that each individual
    # groupby element might not have correct information for.
    fill_max_min_partial = partial(fill_max_min, max_dt, min_dt)
    fill_zeros_partial = partial(fill_zeros, date_list)

    # Apply the functions
    df = df.groupby(by='itm_id', as_index=False) \
        .apply(fill_max_min_partial) \
        .reset_index(drop=True)
    df = df.groupby(by='itm_id', as_index=False) \
        .apply(fill_zeros_partial) \
        .reset_index(drop=True)
    log.debug("Finished filling in missing data took: %s", str(time() - start))

    start = time()
    log.debug("Started pulling features")
    # Pull the features out of the data
    features = get_features(df, df_nz)
    log.debug("Finished getting features in %s", str(time() - start))

    start = time()
    log.debug("Started clustering %s items", str(len(df.itm_id.unique())))
    # Begin clustering with the 'clusterer' using the default desired features
    clusters = clusterer(df, features, num_tasks)
    log.debug("Clustering took: %s", str(time() - start))

    # create the final data frame to upload to 'work_table'
    work_data = clusters.drop(
        columns=['dspl_descr', 'sls_amt']).reset_index(drop=True)

    work_data['store_id'] = store

    start = time()
    log.debug("Uploading the DataFrame to the work table")
    success = data_upload(engine, work_data, 'work_table')
    if success:
        log.debug("Uploaded the DataFrame to the work table in %s",
                  time() - start)
    else:
        log.debug("DATABASE UPLOAD FAILED")
    log.debug("Finished ETL process for store: %s with %s items in %s",
              store,
              str(len(work_data.itm_id.unique())),
              str(time() - mod_start))


if __name__ == '__main__':
    ETL('FrontOff001')
