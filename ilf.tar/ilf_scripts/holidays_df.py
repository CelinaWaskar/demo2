""" Module with the function get_holidays() that returns a data frame of relevant holidays
    from 2015 and after, and the upper_window, lower_window data used by prophet for
    each holiday """

import pandas as pd


def get_holidays(department='all'):
    """ Returns a data frame of relevant holidays from 2015 and after, and
        the upper_window, lower_window data used by prophet for each holiday """
    department = department.lower()
    new_years = pd.DataFrame({
        'holiday': 'New Year',
        'ds': pd.to_datetime(['2015-01-01', '2016-01-01', '2017-01-01',
                              '2018-01-01', '2019-01-01']),
        'lower_window': -2,
        'upper_window': 2,
    })

    mlk_day = pd.DataFrame({
        'holiday': 'MLK Day',
        'ds': pd.to_datetime(['2015-01-19', '2016-01-18', '2017-01-16',
                              '2018-01-15', '2019-01-21']),
        'lower_window': -2,
        'upper_window': 0,
    })

    super_bowl = pd.DataFrame({
        'holiday': 'Super Bowl Day',
        'ds': pd.to_datetime(['2015-02-01', '2016-02-07', '2017-02-05',
                              '2018-02-04', '2019-02-03']),
        'lower_window': -4,
        'upper_window': 0,
    })

    valentines_day = pd.DataFrame({
        'holiday': 'Valentines Day',
        'ds': pd.to_datetime(['2015-02-14', '2016-02-14', '2017-02-14',
                              '2018-02-14', '2019-02-14']),
        'lower_window': -3,
        'upper_window': 0,
    })

    st_patricks_day = pd.DataFrame({
        'holiday': 'St. Patrick\'s Day',
        'ds': pd.to_datetime(['2015-03-17', '2016-03-17', '2017-03-17',
                              '2018-03-17', '2019-03-17']),
        'lower_window': -2,
        'upper_window': 0,
    })

    easter = pd.DataFrame({
        'holiday': 'Easter',
        'ds': pd.to_datetime(['2015-04-05', '2016-03-27', '2017-04-16',
                              '2018-04-01', '2019-04-21']),
        'lower_window': -3,
        'upper_window': 1,
    })

    cinco_de_mayo = pd.DataFrame({
        'holiday': 'Cinco De Mayo',
        'ds': pd.to_datetime(['2015-05-05', '2016-05-05', '2017-05-05',
                              '2018-05-05', '2019-05-05']),
        'lower_window': -2,
        'upper_window': 1,
    })

    mothers_day = pd.DataFrame({
        'holiday': 'Mother\'s Day',
        'ds': pd.to_datetime(['2015-05-10', '2016-05-08', '2017-05-14',
                              '2018-05-13', '2019-05-12']),
        'lower_window': -1,
        'upper_window': 0,
    })

    memorial_day = pd.DataFrame({
        'holiday': 'Memorial Day',
        'ds': pd.to_datetime(['2015-05-25', '2016-05-30', '2017-05-29',
                              '2018-05-28', '2019-05-27']),
        'lower_window': -4,
        'upper_window': 1,
    })

    fathers_day = pd.DataFrame({
        'holiday': 'Father\'s Day',
        'ds': pd.to_datetime(['2015-06-21', '2016-06-19', '2017-06-18',
                              '2018-06-17', '2019-06-16']),
        'lower_window': -1,
        'upper_window': 0,
    })

    independence_day = pd.DataFrame({
        'holiday': 'Independence Day',
        'ds': pd.to_datetime(['2015-07-04', '2016-07-04', '2017-07-04',
                              '2018-07-04', '2019-07-04']),
        'lower_window': -3,
        'upper_window': 1,
    })

    labor_day = pd.DataFrame({
        'holiday': 'Labor Day',
        'ds': pd.to_datetime(['2015-09-07', '2016-09-05', '2017-09-04',
                              '2018-09-03', '2019-09-02']),
        'lower_window': -2,
        'upper_window': 1,
    })

    halloween = pd.DataFrame({
        'holiday': 'Halloween',
        'ds': pd.to_datetime(['2015-10-31', '2016-10-31', '2017-10-31',
                              '2018-10-31', '2019-10-31']),
        'lower_window': -5,
        'upper_window': 1,
    })

    thanksgiving = pd.DataFrame({
        'holiday': 'Thanksgiving',
        'ds': pd.to_datetime(['2015-11-26', '2016-11-24', '2017-11-23',
                              '2018-11-22', '2019-11-28']),
        'lower_window': -5,
        'upper_window': 1,
    })

    christmas = pd.DataFrame({
        'holiday': 'Christmas',
        'ds': pd.to_datetime(['2015-12-25', '2016-12-25', '2017-12-25',
                              '2018-12-25', '2019-12-25']),
        'lower_window': -5,
        'upper_window': 1,
    })

    vitamins_holidays = pd.DataFrame({
        'holiday': 'Vitamins_Holiday',
        'ds': pd.to_datetime([
            '2015-01-07', '2015-01-08', '2015-01-09', '2015-01-10',
            '2015-01-11', '2015-01-12',
            '2015-01-13                                                                                              ',
            '2015-01-14',
            '2015-04-22', '2015-04-23', '2015-04-24', '2015-04-25',
            '2015-04-26', '2015-04-27',
            '2015-04-28                                                                                              ',
            '2015-04-29',
            '2015-07-22', '2015-07-23', '2015-07-24', '2015-07-25',
            '2015-07-26', '2015-07-27',
            '2015-07-28                                                                                              ',
            '2015-07-29',
            '2015-10-21', '2015-10-22', '2015-10-23', '2015-10-24',
            '2015-10-25', '2015-10-26',
            '2015-10-27                                                                                              ',
            '2015-10-28',
            '2016-01-06', '2016-01-07', '2016-01-08', '2016-01-09',
            '2016-01-10', '2016-01-11',
            '2016-01-12                                                                                              ',
            '2016-01-13',
            '2016-04-20', '2016-04-21', '2016-04-22', '2016-04-23',
            '2016-04-24', '2016-04-25',
            '2016-04-26                                                                                              ',
            '2016-04-27',
            '2016-07-20', '2016-07-21', '2016-07-22', '2016-07-23',
            '2016-07-24', '2016-07-25',
            '2016-07-26                                                                                              ',
            '2016-07-27',
            '2016-10-19', '2016-10-20', '2016-10-21', '2016-10-22',
            '2016-10-23', '2016-10-24',
            '2016-10-25                                                                                              ',
            '2016-10-26',
            '2017-01-04', '2017-01-05', '2017-01-06', '2017-01-07',
            '2017-01-08', '2017-01-09',
            '2017-01-10                                                                                              ',
            '2017-01-11',
            '2017-04-19', '2017-04-20', '2017-04-21', '2017-04-22',
            '2017-04-23', '2017-04-24',
            '2017-04-25                                                                                              ',
            '2017-04-26',
            '2017-07-26', '2017-07-27', '2017-07-28', '2017-07-29',
            '2017-07-30', '2017-07-31',
            '2017-08-01                                                                                              ',
            '2017-08-02',
            '2017-10-18', '2017-10-19', '2017-10-20', '2017-10-21',
            '2017-10-22', '2017-10-23',
            '2017-10-24                                                                                              ',
            '2017-10-25',
            '2018-01-03', '2018-01-04', '2018-01-05', '2018-01-06',
            '2018-01-07', '2018-01-08',
            '2018-01-09                                                                                              ',
            '2018-01-10',
            '2018-04-18', '2018-04-19', '2018-04-20', '2018-04-21',
            '2018-04-22', '2018-04-23',
            '2018-04-24                                                                                              ',
            '2018-04-25',
            '2018-07-25', '2018-07-26', '2018-07-27', '2018-07-28',
            '2018-07-29', '2018-07-30',
            '2018-07-31                                                                                              ',
            '2018-08-01',
            '2018-10-17', '2018-10-18', '2018-10-19', '2018-10-20',
            '2018-10-21', '2018-10-22',
            '2018-10-23                                                                                              ',
            '2018-10-24',
            '2019-01-02', '2019-01-03', '2019-01-04', '2019-01-05',
            '2019-01-06', '2019-01-07',
            '2019-01-08                                                                                              ',
            '2019-01-09',
            '2019-04-24', '2019-04-25', '2019-04-26', '2019-04-27',
            '2019-04-28', '2019-04-29',
            '2019-04-30                                                                                              ',
            '2019-05-01',
            '2019-07-24', '2019-07-25', '2019-07-26', '2019-07-27',
            '2019-07-28', '2019-07-29',
            '2019-07-30                                                                                              ',
            '2019-07-31',
            '2019-10-16', '2019-10-17', '2019-10-18', '2019-10-19',
            '2019-10-20', '2019-10-21',
            '2019-10-22                                                                                              ',
            '2019-10-23'

        ]),
        'lower_window': 0,
        'upper_window': 0

    })

    if department == 'vitamins':
        return pd.concat((new_years,
                          mlk_day,
                          super_bowl,
                          valentines_day,
                          st_patricks_day,
                          easter,
                          cinco_de_mayo,
                          mothers_day,
                          memorial_day,
                          fathers_day,
                          independence_day,
                          labor_day,
                          halloween,
                          thanksgiving,
                          christmas, vitamins_holidays))
    else:
        return pd.concat((new_years,
                          mlk_day,
                          super_bowl,
                          valentines_day,
                          st_patricks_day,
                          easter,
                          cinco_de_mayo,
                          mothers_day,
                          memorial_day,
                          fathers_day,
                          independence_day,
                          labor_day,
                          halloween,
                          thanksgiving,
                          christmas,))
