"""
This module will contain numerous models that are to be used for item
level forecasting.
"""

# Set the Openblas library to use a maximum of one thread.
import os

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

from datetime import timedelta
import logging
from timeit import default_timer as time

import numpy as np
import pandas as pd
import statsmodels.api as sm
from fbprophet import Prophet
from fbprophet.diagnostics import cross_validation, performance_metrics
from ilf_scripts.utils.forecasting_utils.get_events import get_events
from ilf_scripts.utils.forecasting_utils.hyperopt_funcs import mae
from ilf_scripts.utils.silence.suppress_output import suppress_output
from hyperopt import STATUS_OK, STATUS_FAIL
import xgboost as xgb
from sklearn.preprocessing import StandardScaler

log = logging.getLogger('ilf')
log.setLevel(logging.DEBUG)


class model:
    """
    This class is a parent class that will provide dummy functions for
    each individual model to a child-class
    """

    def __init__(self, model, params=None):
        self.model = model
        self.params = params

    def get_model(self):
        if self.model == 'fbprophet':
            return prophet()

        if self.model == 'sarimax':
            return sarimax()

        if self.model == 'arima':
            return arima()

        if self.model == 'xgboost':
            return xgboost()


class prophet(model):
    """
    Implements the prophet model
    """

    def __init__(self):
        """
        Initializes all the parameters for the model to use.
        """
        self.add_holidays = False
        self.train_data = None
        self.best = None
        self.m = None
        self.future = None
        self.forecast = None
        self.forecast_gap = None
        self.end_date = None
        self.use_date_till = None
        self.hmp = False

    def set_train_data(self, train_data, forecast_gap,
                       use_date_till=None, end_date=None, hmp=False):
        """
        This sets the training data for the model
        :param train_data: The training data
        :param forecast_gap: The number of days to forecast
        :param use_date_till: The date that train data ends
        :param end_date: The date that test data ends
        :param hmp: The has many peaks boolean
        :return: None
        """
        self.train_data = train_data
        self.forecast_gap = forecast_gap
        self.use_date_till = use_date_till,
        self.end_date = end_date
        # Remove peaks
        # If the item is flagged as having many peaks, remove them
        # TODO: Add a check here to see if the date we are forecasting is
        #       one of these peaks.
        if self.hmp:
            print(self.train_data.columns)
            print(self.train_data)
            fake_holidays = get_events(self.train_data)
            # Remove the peaks from the training data.
            self.train_data['new_y'] = self.train_data['y'][
                ~self.train_data.ds.isin(fake_holidays)]
            nans, x = np.isnan(self.train_data['new_y'].values), lambda z: \
                z.nonzero()[0]
            self.train_data['new_y'][nans] = np.interp(x(nans),
                                                       x(~nans),
                                                       self.train_data[
                                                           'new_y'][~nans])
            self.train_data.drop(columns=['y'], inplace=True)
            self.train_data = self.train_data.rename(columns={'new_y': 'y'})
            del nans
            del fake_holidays

    def set_parameters(self, best, holidays=None):
        """
        Sets the hyper parameters of the model (as determined by hyperopt
        :param best: A dictionary of hyper parameters
        :param holidays: Boolean to add holidays or not
        :return: None
        """
        self.best = best
        if holidays is None:
            self.add_holidays = True

    def fit_predict(self):
        """
        Fit and predict the model
        :return:
        """
        best_cp = self.best.copy()
        if 'type' in best_cp:
            del best_cp['type']
        self.m = Prophet(**best_cp)
        if self.add_holidays:
            self.m.add_country_holidays(country_name='US')
        # Suppress the output from STANs optimzer
        with suppress_output():
            self.m.fit(self.train_data, algorithm='Newton')
        self.future = self.m.make_future_dataframe(periods=self.forecast_gap,
                                                   freq='W-MON',
                                                   include_history=False)
        self.forecast = self.m.predict(self.future)
        return self.forecast

    def hp_objective(self, params):
        """
        Returns the objective function of the model
        :param params: The hyperopt parameters
        :return: func, The objective function
        """
        return get_prophet_hp_objective(self.train_data, params)


class sarimax(model):
    """
    The SARIMA model
    """

    def __init__(self):
        """
        Initializes the parameters of the model's class
        """
        self.train_data = None
        self.m = None
        self.results = None
        self.forecast_gap = None
        self.p = 0
        self.d = 0
        self.q = 0
        self.P = 0
        self.D = 0
        self.Q = 0
        self.m = 0
        self.forecast_start = None
        self.forecast_end = None
        self.forecast = None
        self.holidays = None
        self.best = None

    def set_train_data(self, train_data, forecast_gap, use_date_till=None,
                       end_date=None, hmp=None):
        """
        Sets the training data
        :param train_data: The training data
        :param forecast_gap: The number of days to forecast out
        :param use_date_till: The last day of the train data
        :param end_date: The last dat of the test data
        :return: None
        """
        self.train_data = train_data.set_index('ds')
        self.forecast_gap = forecast_gap
        self.forecast_start = use_date_till
        self.forecast_end = end_date

    def set_parameters(self, best, holidays=None):
        """
        Sets the parameters of the model from the hyperopt dictionary
        NOTE: For this model to work the dictionary must be broken down and
        assigned
        :param best: The hyperopt trail dictionary
        :param holidays: Bool to use holidays or not, Not Applicable
        :return: None
        """
        self.best = best
        self.holidays = None
        self.p = best['p']
        self.d = best['d']
        self.q = best['q']
        self.P = best['P']
        self.D = best['D']
        self.Q = best['Q']
        self.m = best['m']

    def fit_predict(self):
        """
        Fit and predict the model
        :return:
        """
        self.m = sm.tsa.statespace.SARIMAX(self.train_data,
                                           order=(int(self.p),
                                                  int(self.d),
                                                  int(self.q)),
                                           freq='W-MON',
                                           seasonal_order=(int(self.P),
                                                           int(self.D),
                                                           int(self.Q),
                                                           int(self.m)),
                                           enforce_stationarity=False,
                                           enforce_invertibility=False, ).fit(
            disp=0, **{'n_jobs': 1})

        self.forecast = self.m.get_prediction(
            self.forecast_start + timedelta(days=7),
            self.forecast_end
        )

        return self.forecast.summary_frame().reset_index() \
            .drop(columns='mean_se') \
            .rename(columns={'index': 'ds',
                             'mean': 'yhat',
                             'mean_ci_lower': 'yhat_lower',
                             'mean_ci_upper': 'yhat_upper'}) \
            .reset_index(drop=True)

    def hp_objective(self, params):
        """
        Retrun the objective function for use in hyperopt
        :param params: The parameters for hyperopt to use
        :return: func, The hyperopt objective function
        """
        return get_sarimax_hp_objective(self.train_data, params)


class arima(model):
    """
    The ARIMA model
    """

    def __init__(self):
        """
        Defines the parameters for the model's class
        """
        self.train_data = None
        self.m = None
        self.results = None
        self.forecast_gap = None
        self.p = 0
        self.d = 0
        self.q = 0
        self.P = 0
        self.D = 0
        self.Q = 0
        self.m = 0
        self.forecast_start = None
        self.forecast_end = None
        self.forecast = None
        self.holidays = None
        self.best = None

    def set_train_data(self, train_data, forecast_gap, use_date_till=None,
                       end_date=None, hmp=None):
        """
        Sets the training data
        :param train_data: The train data
        :param forecast_gap: The number of days to forecast
        :param use_date_till: The last day of the training data
        :param end_date: The last day of the testing data
        :return: None
        """
        self.train_data = train_data.set_index('ds')
        self.forecast_gap = forecast_gap
        self.forecast_start = use_date_till
        self.forecast_end = end_date

    def set_parameters(self, best, holidays=None):
        """
        Declares the parameter values
        :param best: The values of the parameters
        :param holidays: Whether or not to use holidays, Not Applicable
        :return: None
        """
        self.best = best
        self.holidays = None
        self.p = best['p']
        self.d = best['d']
        self.q = best['q']

    def fit_predict(self):
        """
        Fit and predict the model.
        :return:
        """
        self.m = sm.tsa.statespace.SARIMAX(self.train_data,
                                           order=(int(self.p),
                                                  int(self.d),
                                                  int(self.q)),
                                           freq='W-MON',
                                           seasonal_order=(int(self.P),
                                                           int(self.D),
                                                           int(self.Q),
                                                           int(self.m)),
                                           enforce_stationarity=False,
                                           enforce_invertibility=False, ).fit(
            disp=0, **{'n_jobs': 1})

        self.forecast = self.m.get_prediction(
            self.forecast_start + timedelta(days=7),
            self.forecast_end
        )

        return self.forecast.summary_frame().reset_index() \
            .drop(columns='mean_se') \
            .rename(columns={'index': 'ds',
                             'mean': 'yhat',
                             'mean_ci_lower': 'yhat_lower',
                             'mean_ci_upper': 'yhat_upper'}) \
            .reset_index(drop=True)

    def hp_objective(self, params):
        """
        Returns the hyperopt objective function
        :param params: The params to use in the objective function
        :return:
        """
        return get_arima_hp_objective(self.train_data, params)


class xgboost(model):

    def __init__(self):
        self.add_holidays = False
        self.train_data = None
        self.best = None
        self.m = None
        self.future = None
        self.forecast = None
        self.forecast_gap = None
        self.end_date = None
        self.use_date_till = None
        self.hmp = False
        self.X_train = None
        self.y_train = None
        self.X_forecast = None
        self.train_data_raw = None

    def set_train_data(self, train_data, forecast_gap, use_date_till=None,
                       end_date=None, hmp=None):
        self.train_data_raw = train_data.copy()
        self.train_data = train_data
        self.end_date = end_date
        self.train_data['weekofyear'] = self.train_data['ds'].dt.weekofyear
        self.train_data['month'] = self.train_data['ds'].dt.month
        self.train_data['quarter'] = self.train_data['ds'].dt.quarter

        self.X_forecast = pd.DataFrame([end_date], columns=['ds'])
        self.X_forecast['weekofyear'] = self.X_forecast['ds'].dt.weekofyear
        self.X_forecast['month'] = self.X_forecast['ds'].dt.month
        self.X_forecast['quarter'] = self.X_forecast['ds'].dt.quarter

        len_of_data = self.train_data.__len__()
        lags = round(len_of_data / 1)
        number_of_lags = lags * 1

        log.debug('%s LAG FEATURES CREATED', number_of_lags)
        for i in range(1, number_of_lags):
            self.train_data['lag_' + str(i)] = self.train_data['y'] \
                .shift(i, fill_value=0)
            self.X_forecast['lag_' + str(i)] = \
                self.train_data[['ds', 'y']].sort_values(by='ds',
                                                         ascending=False)[
                    'y'].shift(i, fill_value=0)
        self.X_train = self.train_data[self.train_data.columns[
            ~self.train_data.columns.isin(['ds', 'y'])]]

        self.y_train = self.train_data['y']

        # Create the forecast feature set.

        scaler = StandardScaler()
        X_total = pd.concat([self.X_train, self.X_forecast], sort=False)
        X_total = X_total.drop(columns=['ds'])
        X_total = pd.DataFrame(scaler.fit_transform(X_total),
                               columns=X_total.columns)
        self.X_forecast = X_total.iloc[-1:]
        self.X_train = X_total.iloc[:-1]

        X_total = None

    def set_parameters(self, best, holidays=None):
        self.best = best

    def fit_predict(self):
        self.m = xgb.XGBRegressor(**self.best)
        self.m.fit(self.X_train, self.y_train)
        self.forecast = self.m.predict(self.X_forecast)
        self.forecast = pd.DataFrame(data=[[self.end_date,
                                            self.forecast[0], 0, 0]],
                                     columns=['ds', 'yhat',
                                              'yhat_upper', 'yhat_lower'])
        return self.forecast


    def hp_objective(self, params):
        return get_xgboost_hp_objective(self.train_data_raw,
                                        self.end_date,
                                        params)


###############################################################################
# DEFINE THE HYPEROPT OBJECTIVE PER MODEL #####################################
###############################################################################

def get_arima_hp_objective(train_data, params):
    """
    The objective function for ARIMA, acts the same way as ARIMA
    :param train_data: The training data
    :param params: The params from hyperopt
    :return:
    """

    try:
        start_time = time()
        # Do the same kind of cross validation on SARIMA as prophet
        init_train = train_data.iloc[:round(.95 * train_data.__len__())]
        step_through = train_data[~train_data.isin(init_train)].dropna()
        yhat, y = [], []

        # Check and see if the training data's index is 'ds'
        if init_train.index.name is not 'ds':
            init_train.set_index('ds', inplace=True)
            step_through.set_index('ds', inplace=True)

        # Do the cross validation steps
        irange = step_through.__len__()
        log.debug("Doing %s cross validations", irange)
        for i in range(irange):
            sarima = sm.tsa.statespace.SARIMAX(init_train,
                                               order=(int(params['p']),
                                                      int(params['d']),
                                                      int(params['q'])),
                                               seasonal_order=(0, 0, 0, 0),
                                               freq='W-MON',
                                               enforce_stationarity=False,
                                               enforce_invertibility=False,
                                               trend=params['trend'])
            forecasting = step_through.loc[step_through.index[0]]
            sarima = sarima.fit(disp=0, **{'n_jobs': 1})
            forecast = sarima.get_prediction(step_through.index.values[0])
            yhat.append(forecast.summary_frame().values[0][0])
            y.append(step_through.loc[step_through.index[0]].y)
            init_train = init_train.append(forecasting)
            step_through = step_through[1:]
        total_time = time() - start_time
        loss = mae(y, yhat)
        return {'loss': loss, 'status': STATUS_OK, 'eval_time': total_time}
    except ValueError as e:
        print(str(e))
        return {'status': STATUS_FAIL}
    except:
        log.debug("Something real bad happened")
        return {'status': STATUS_FAIL}


def get_sarimax_hp_objective(train_data, params):
    """
    Perform cross validation on the last %10 of training data and return the
    MAE for hyperopt as the loss function
    :param train_data: The training data
    :param params: The model parameters
    :return: float, MAE
    """
    # import mkl
    # mkl.set_num_threads(1)
    try:
        start_time = time()
        # Do the same kind of cross validation on SARIMA as prophet
        init_train = train_data.iloc[:round(.95 * train_data.__len__())]
        step_through = train_data[~train_data.isin(init_train)].dropna()
        yhat, y = [], []

        # Check and see if the training data's index is 'ds'
        if init_train.index.name is not 'ds':
            init_train.set_index('ds', inplace=True)
            step_through.set_index('ds', inplace=True)

        # Do the cross validation steps
        irange = step_through.__len__()
        log.debug("Doing %s cross validations", irange)
        for i in range(irange):
            sarima = sm.tsa.statespace.SARIMAX(init_train,
                                               order=(int(params['p']),
                                                      int(params['d']),
                                                      int(params['q'])),
                                               seasonal_order=(
                                                   int(params['P']),
                                                   int(params['D']),
                                                   int(params['Q']),
                                                   int(params['m'])),
                                               freq='W-MON',
                                               enforce_stationarity=False,
                                               enforce_invertibility=False,
                                               trend=params['trend'])
            forecasting = step_through.loc[step_through.index[0]]
            sarima = sarima.fit(disp=0, **{'n_jobs': 1})
            forecast = sarima.get_prediction(step_through.index.values[0])
            yhat.append(forecast.summary_frame().values[0][0])
            y.append(step_through.loc[step_through.index[0]].y)
            init_train = init_train.append(forecasting)
            step_through = step_through[1:]
        total_time = time() - start_time
        loss = mae(y, yhat)
        return {'loss': loss, 'status': STATUS_OK, 'eval_time': total_time}
    except ValueError as e:
        print(str(e))
        return {'status': STATUS_FAIL}
    except Exception as e:
        print(str(e))
        return {'status': STATUS_FAIL}


def get_prophet_hp_objective(train_data, params):
    """
    Returns the average MAE from Cross Validation
    values from given hyper parameters, allow for a failure in prophet to
    occur from negative values
    :param train_data: The training data used to fit the model
    :param params: The hyperopt parameters
    :return: dict with information about the loss as well as status.
    """
    try:
        start_time = time()
        # Create the model m with given hyperparameters
        train_model = Prophet(daily_seasonality=False,
                              weekly_seasonality=False,
                              **params)
        # Add built in holidays to the model
        train_model.add_country_holidays(country_name='US')

        with suppress_output():
            train_model.fit(train_data, algorithm='Newton')

        # Set up prophet for leave-one-out cross validation
        init_train_data = np.floor(.95 * train_data.__len__())
        initial = str(init_train_data) + ' W'
        period = '1 W'
        horizon = '1 W'
        with suppress_output():
            df_cv = cross_validation(train_model,
                                     initial=initial,
                                     period=period,
                                     horizon=horizon, )

        # Return the loss as the average MAPE of the CV runs
        df_p = performance_metrics(df_cv)
        total_time = time() - start_time
        log.debug("Hyperopt took %s seconds", total_time)
        return {'loss': np.mean(df_p['mae']),
                'status': STATUS_OK,
                'eval_time': total_time}
    except ValueError:
        log.debug(str(ValueError))
        return {'status': STATUS_FAIL}
    except RuntimeError:
        log.debug("Runtime Error, check logs")
        return {'status': STATUS_FAIL}


def get_xgboost_hp_objective(train_data, end_date, params):
    try:
        start_time = time()
        if train_data.index.name is 'ds':
            train_data.reset_index(inplace=True)
        # Follow the same approach as SARIMA in this cross validation
        init_train = train_data.iloc[:round(.95 * train_data.__len__())].copy(deep=True)
        step_through = train_data[~train_data.isin(init_train)].copy(deep=True).dropna()
        yhat, y = [], []
        irange = step_through.__len__()
        log.debug("Doing %s cross validations", irange)
        for _ in range(irange):
            # Grab the first date to test
            end_date = step_through.ds.values[0]

            # Create the date features for init_train
            init_train['weekofyear'] = init_train['ds'].dt.weekofyear
            init_train['month'] = init_train['ds'].dt.month
            init_train['quarter'] = init_train['ds'].dt.quarter

            # Create the X_forecast variable
            X_forecast = pd.DataFrame([end_date], columns=['ds'])
            X_forecast['weekofyear'] = X_forecast['ds'].dt.weekofyear
            X_forecast['month'] = X_forecast['ds'].dt.month
            X_forecast['quarter'] = X_forecast['ds'].dt.quarter
            X_forecast.drop(columns=['ds'], inplace=True)

            # Add the lag features
            len_of_data = init_train.__len__()
            lags = round(len_of_data / 1)
            number_of_lags = lags * 1
            log.debug('%s LAG FEATURES CREATED', number_of_lags)
            for i in range(1, number_of_lags):
                init_train['lag_' + str(i)] = init_train['y'] \
                    .shift(i, fill_value=0)
                X_forecast['lag_' + str(i)] = init_train.sort_values(by=['ds'],
                                                                     ascending=
                                                                     False) \
                    ['y'].shift(i, fill_value=0)

            # Create X_train from init_train
            X_train, y_train = init_train[init_train.columns[
                ~init_train.columns.isin(['ds', 'y'])]], init_train['y']

            # Scale the data to be standard
            scaler = StandardScaler()
            X_total = pd.concat([X_train, X_forecast], sort=False)
            X_total = pd.DataFrame(scaler.fit_transform(X_total),
                                   columns=X_total.columns).fillna(0)
            X_forecast = X_total.iloc[-1:]

            X_train = X_total.iloc[:-1]

            m = xgb.XGBRegressor(**params)
            m.fit(X_train, y_train)
            forecast = m.predict(X_forecast)
            y.append(step_through.iloc[0].y)
            yhat.append(forecast[0])
            init_train = init_train.append(step_through.iloc[0])
            step_through = step_through[1:]

        return {'loss': np.mean(mae(y, yhat)),
                'status': STATUS_OK,
                'eval_time': time() - start_time}

    except ValueError as e:
        print(str(e))
        return {'status': STATUS_FAIL}
