"""
This modules contains the hyperopt space as well as the objective functions
"""

# Set the Openblas library to use a maximum of one thread.
import os

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

import logging

import numpy as np
from hyperopt import hp
from sklearn.metrics import mean_absolute_error

from ilf_scripts.utils.forecasting_utils import models

# Set the module wide logger
log = logging.getLogger('ilf')
log.setLevel(logging.DEBUG)


def mape(y_true, y_pred):
    """
    Returns the mean absolute percent error
    :param y_true: The true values of y
    :param y_pred: The predicted values of y
    :return: float, the MAPE
    """
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    if np.count_nonzero(y_true) > 0:
        return abs(np.mean(np.abs((y_true - y_pred) / y_true)))
    return -100


def mae(y_true, y_pred):
    """
    Returns the mean absolute error
    :param y_true: The true values of y
    :param y_pred: The predicted values of y
    :return: float, the MAE
    """
    return mean_absolute_error(y_true, y_pred)


def model_selection_space():
    """
    This defines the model selection "space". It returns a hp.choice of
    multiple models each with their own space.
    :return: hp.choice space
    """
    sarima_space = {'type': 'sarimax',
                    'p': hp.quniform('p', 0, 5, 1),
                    'd': hp.quniform('d', 0, 1, 1),
                    'q': hp.quniform('q', 0, 5, 1),
                    'P': hp.quniform('P', 0, 2, 1),
                    'D': hp.quniform('D', 0, 1, 1),
                    'Q': hp.quniform('Q', 0, 2, 1),
                    'm': hp.choice('m', [0, 4, 13]),
                    'trend': hp.choice('trend', ['n', 'c', 't', 'ct'])
                    }
    fbprophet_space = {
        'type': 'fbprophet',
        "holidays_prior_scale": hp.uniform("hps", 5.0, 10.0),
        "changepoint_prior_scale": hp.uniform("cpps", 0.001, 0.7),
        "yearly_seasonality": hp.quniform("ys", 5.0, 10.0, 1),
        "seasonality_prior_scale": hp.uniform("sps", 5.0, 15.0),
    }
    arima_space = {
        'type': 'arima',
        'p': hp.quniform('a', 0, 5, 1),
        'd': hp.quniform('b', 0, 1, 1),
        'q': hp.quniform('c', 0, 5, 1),
        'trend': hp.choice('tr', ['n', 'c', 't', 'ct'])
    }
    xgboost_space = {
        'type': 'xgboost',
        'n_estimators': hp.choice('n_estimators', np.arange(100, 1000)),
        'learning_rate': hp.uniform('learning_rate', 0.05, 0.3),
        'max_depth': hp.choice('max_depth', np.arange(3, 20)),
        'min_child_weight': hp.uniform('min_child_weight', 1, 20),
        'subsample': hp.uniform('subsample', 0.5, 1),
        'reg_lambda': hp.uniform('reg_lambda', 0.01, 100),
        'reg_alpha': hp.uniform('reg_alpha', 0.01, 100),
        'gamma': hp.uniform('gamma', 0.5, 1),
        'colsample_bytree': hp.uniform('colsample_bytree', 0.5, 1),
        'silent': 1,
        'n_jobs': 1
    }

    space = [fbprophet_space, xgboost_space]
    return hp.choice('model', space)


def model_objective(train_data, forecast_gap, use_date_till, end_date,
                    hmp, params):
    """
    This is the objective function, which returns the loss of the model
    :param train_data: The training data
    :param forecast_gap: How far out to forecast
    :param use_date_till: The date the training data ends
    :param end_date: The date that the test data ends
    :param test_data: The test data
    :param params: The hyperopt parameters
    :return: Hyperopt trail
    """
    log.debug('Evaluating with parameters')
    print(params)
    model_name = params['type']
    del params['type']
    m = models.model(model_name).get_model()
    m.set_train_data(train_data, forecast_gap, use_date_till, end_date, hmp)
    m.set_parameters(params, holidays=True)
    best = m.hp_objective(params)
    print(best)
    if 'loss' in best:
        log.debug("Score for %s was %s", model_name, str(best['loss']))
    else:
        log.debug("Invalid parameter selection for %s", model_name)
    return best
