import logging

import pandas as pd

log = logging.getLogger('ilf')
log.setLevel(logging.DEBUG)


def error_log(err, engine, itm_id=None, len_df=None, end_date=None):
    """
    Logs errors based on an err id provided
    param: err: The error code
    """
    if err == 0:
        log.debug('Itm_id: %s skipped due to insufficient data', itm_id)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [0]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 1:
        log.debug('Itm_id: %s skipped due to insufficient data', itm_id)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [1]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 2:
        log.debug('Itm_id: %s skipped due to insufficient number \\\
                    of y values', itm_id)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [2]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 3:
        log.debug('Test date %s does not exists', end_date)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [3]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 4:
        log.debug('Hyperopt failed to have any values in its sequence')
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [4]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
