"""
This module locates the "peaks" of a time series and returns their date
"""

import numpy as np
import pandas as pd
from scipy.signal import find_peaks


def get_events(df):
    """
    Locates the events for which there are abnormal sales
    :param df: The DataFrame for the itm
    :param start_date: The date to start from
    :param end_date: The date time end
    :return: List of events
    """
    # Calculate the peaks of the data
    peaks, peak_heights = find_peaks(-df['y'])

    # Get the data and time parts of the peaks
    data_part = df['y'][peaks[0]:peaks[-1]]
    time_part = df['ds'][peaks[0]:peaks[-1]]

    # Get the date index
    index_date = time_part.index[time_part != 0].values

    # Interpolate the 'baseline' of the function.
    baseline = np.interp(index_date, peaks, df['y'][peaks])
    data_without_baseline = data_part - baseline
    data_without_baseline = data_without_baseline.reset_index(drop=True)

    # Find the negative values and set it equal to 0.
    loc_neg = np.where(data_without_baseline < 0)

    data_without_baseline[loc_neg[0]] = 0

    time_part_index_new = time_part.reset_index(drop=True)

    # extract year information and get the end location of each year
    time_part_0 = pd.DatetimeIndex(time_part_index_new).year

    # Create a list of the indexes for which the years lie between

    loc = [np.where(time_part_0 == x)[0].max() + 1 for x in
           time_part_0.unique()]

    loc.insert(0, 0)

    for j in range(time_part_0.nunique()):  # 3 years
        date_name = pd.DataFrame(data={
            'ds': time_part_index_new[loc[j]:loc[j + 1]].reset_index(
                drop=True),
            'y': data_without_baseline[loc[j]:loc[j + 1]].reset_index(
                drop=True)})
        date_name['ds'] = pd.to_datetime(date_name['ds'])
        date_name['ds'] = pd.to_datetime(date_name['ds'].dt.strftime('%m-%d'),
                                         format='%m-%d')
        if j == 0:
            new_data_all_date = date_name
        else:
            new_data_all_date = pd.merge_ordered(new_data_all_date, date_name,
                                                 on='ds')

    col_names = ['qty' + str(x) for x in time_part_0.unique()]

    col_names.insert(0, 'ds')

    new_data_all_date.columns = col_names
    new_data_all_date = new_data_all_date.fillna(0)

    mean_data = (new_data_all_date['qty2017'] + new_data_all_date['qty2018'] +
                 new_data_all_date['qty2019']) / 3
    new_loc = np.where(mean_data > 0.6 * mean_data.max())

    # Find data driven holidays in each year & Calculate the mean
    # and std of normal distribution
    fake_holiday = []
    for year in time_part_0.unique():
        fake_holiday_0 = new_data_all_date['ds'][new_loc[0]].apply(
            lambda x: x.replace(year=year))
        fake_holiday = fake_holiday + fake_holiday_0.tolist()

    return fake_holiday
