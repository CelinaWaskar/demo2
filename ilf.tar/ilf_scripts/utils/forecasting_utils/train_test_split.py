"""
This modules contains the code to split a DataFrame by date for training and
testing data sets for use in prophet and other algorithms.
TODO: This file may expand depending on what algorithm is chosen, i.e
      expect that this may return more than just a date 'ds' and actual 'y'
      but also features.
"""

import pandas as pd


def train_test_split(df, start_date, use_date_till, end_date):
    """
    Create the training and testing data
    param: df: The dataframe with the data to split
    param: start_date: The date to start in the training data
    param: use_date_till: The date to use for training data, and the date
                          which the test data begins
    param: end_date: The date which is forecast.
    """

    start_date = pd.Timestamp(start_date)
    use_date_till = pd.Timestamp(use_date_till)

    # Create the training data for each item
    train_ds = df.loc[(df.dt >= start_date)
                      & (df.dt <= use_date_till)].dt
    train_y = df.loc[(df.dt >= start_date)
                     & (df.dt <= use_date_till)].sls_qty
    train_data = pd.DataFrame({
        'ds': train_ds,
        'y': train_y
    }).sort_values(by='ds').reset_index(drop=True)

    # Create the test data
    test_ds = df.loc[(df.dt > use_date_till)
                     & (df.dt <= end_date)].dt
    test_y = df.loc[(df.dt > use_date_till)
                    & (df.dt <= end_date)].sls_qty
    test_data = pd.DataFrame({
        "ds": test_ds,
        "y": test_y
    }).reset_index(drop=True)

    return train_data, test_data
