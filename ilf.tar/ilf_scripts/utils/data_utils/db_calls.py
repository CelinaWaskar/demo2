"""
This modules contains the function to query the data for the ETL as well as
for forecasting
"""
import io

import pandas as pd
import pandas.io.sql as psqlio


def etl_query(store: str,
              engine: object = None,
              query: str = None) -> pd.DataFrame:
    """
    Query a database and get relevant information about a store
    :param store: The store to query data about
    :param engine: The SQLAlchemy engine used to connect to the database
    :param query: The SQL query
    :return: None
    """

    # Pull the data from the database and save it into a data frame
    if query is None:
        query = """
        WITH A1 AS (
        SELECT
            itm_id,
            dspl_descr,
            dep_descr,
            dt,
            sls_qty,
            sls_amt,
            store_id
        FROM
            ilf_sales_data
        WHERE
            store_id='{store}' AND
            dt < '2019-05-01'
        ),

        B1 AS (
        SELECT DISTINCT
            itm_id,
            dt
        FROM
            A1
        GROUP BY
            itm_id, dt
        HAVING
            MAX(dt) > '2019-04-01'
        )

        SELECT DISTINCT
            b.itm_id,
            a.dspl_descr,
            a.dt,
            a.sls_qty,
            a.sls_amt
        FROM A1 AS a
        INNER JOIN B1 AS b
        ON (a.itm_id = b.itm_id);
        """.format(store=store)

    with engine.connect() as connection:
        df = psqlio.read_sql(query, connection)

    df.itm_id = pd.to_numeric(df.itm_id, downcast='integer')
    df.dt = pd.to_datetime(df.dt)

    return df


def data_upload(engine, df, table,
                if_exists='append', sep='\t', encoding='utf8'):
    """
    This function is a fast method to upload large DataFrames to a SQL Server
    using pythons built in IO
    :param engine: A SQL Alchemy engine
    :param df: The DataFrame to be written to the database
    :param table: What table the DataFrame should be written to
    :param if_exists: What to do if the table already exists
    :param sep: The 'delimiter' between values in a csv/excel file
    :param encoding: The encoding of the text
    :return: 1 if success, else failed.
    """
    # Create of append to the table
    df.head(0).to_sql(table, engine, if_exists=if_exists, index=False)

    # Create a formatted output string stream
    output = io.StringIO()
    df.to_csv(output, sep=sep, header=False, encoding=encoding, index=False)
    output.seek(0)

    # Bulk insert the data from the in-memory io stream
    connection = engine.raw_connection()
    cursor = connection.cursor()
    cursor.copy_from(output, table, sep=sep, null='')
    connection.commit()
    cursor.close()

    return 1
