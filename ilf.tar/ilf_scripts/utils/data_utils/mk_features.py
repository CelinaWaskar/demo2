"""
This modules will take a number of different data frames and return an array
of features calculated from the data.
"""

import numpy as np
import pandas as pd
from scipy.signal import find_peaks


def get_features(df: pd.DataFrame, df_nz: pd.DataFrame) -> pd.DataFrame:
    """
    This functions takes in a pandas DataFrame and returns an array of features
    about each item id
    :param df: The preprocessed DataFrame
    :param df_nz: The preprocessed DataFrame sans zeros
    :return: pd.DataFrame: with list of features
    """
    # Group the items by item id
    itm_grouped = df.groupby(['itm_id'], as_index=False)
    itm_grouped_nz = df_nz.groupby(['itm_id'])

    # Extract some of the features
    itm_ids = itm_grouped.apply(lambda x: x.name).reset_index(drop=True)

    # Get the max values of each item
    maxes = itm_grouped.max().rename(columns={'sls_qty': 'sls_qty_max',
                                              'sls_amt': 'sls_amt_max'})\
                       .reset_index(drop=True)

    # Get the minimum values of each item
    mins = itm_grouped.min().rename(columns={'sls_qty': 'sls_qty_min',
                                             'sls_amt': 'sls_amt_min'})\
                      .reset_index(drop=True)

    # Get the means of each item
    means = itm_grouped.mean().rename(columns={'sls_qty': 'sls_qty_mean',
                                               'sls_amt': 'sls_amt_mean'})\
                       .reset_index(drop=True)

    # Get the standard deviation of each item
    stds = itm_grouped.std().rename(columns={'sls_qty': 'sls_qty_std',
                                             'sls_amt': 'sls_amt_std'})\
                      .reset_index(drop=True)

    # Get the median of each item
    medians = itm_grouped.median().rename(columns={'sls_qty': 'sls_qty_med',
                                                   'sls_amt': 'sls_amt_med'})\
                         .reset_index(drop=True)

    # Get the total number of data points (i.e count of dates)
    date_count = itm_grouped_nz.count().rename(
        columns={'dt': 'dt_count'}).dt_count.reset_index(drop=True)

    # Get the average length between sales of the item
    delta_dt = pd.DataFrame(data=itm_grouped_nz['itm_id', 'dt'].apply(
        lambda x: x.dt.diff().mean() / np.timedelta64(1, 'D'))).reset_index()

    # Quantile of Empiric Distribution Function
    def rm_outliers(df: pd.DataFrame) -> float:
        """
        This function returns the number of 'outliers', i.e values that fall
        out of a 90% confidence interval
        param: df: A pd.DataFrame that has the sales information for each date
                   for an item
        return: int: Number of data points outside the confidence interval
        """
        q = df.quantile(q=[0.05, .95])
        return (len(df.loc[(df.sls_qty < q.iloc[0, 1])]) + len(
            df.loc[df.sls_qty > q.iloc[1, 1]])) / len(df)

    # Has large std function
    def has_large_std(df: pd.DataFrame) -> int:
        """
        Checks to see if the item has a large standard deviation relative to
        the difference of the max and min div by 2
        param: df: A pd.DataFrame that has the sales information for each date
                   for an item
        return: Boolean 0 or 1
        """
        std_comp = (df.sls_qty.max() - df.sls_qty.min()) / 2.0
        x = []
        if df.sls_qty.std() > std_comp:
            return 1
        else:
            return 0

    # Has large number of peaks function
    def large_num_peaks(df: pd.DataFrame) -> list:
        """
        Calculates the number and the percentage of peaks relative to the
        data's size
        param: df: A pd.DataFrame that has the sales information for each date
                   for an item
        return: list of integers with number of peaks, and total percentage of
                peaks
        """
        peaks, _ = find_peaks(df.sls_qty)
        return [len(peaks), len(peaks) / len(df)]

    # Quantile of Empirical Distribution Function
    qoedf = pd.DataFrame(data=df.groupby('itm_id').apply(rm_outliers))

    # Has large standard deviation
    hlstd = pd.DataFrame(data=df.groupby('itm_id').apply(has_large_std))

    # Number and Percentage of peaks
    peaks = pd.DataFrame(
        df.groupby('itm_id').apply(large_num_peaks).values.tolist(),
        columns=['peaks_num', 'peaks_percent'])

    # Create the features data frame
    features = pd.concat(
        [itm_ids, maxes, mins, medians, means, stds, date_count], axis=1)
    features = features.loc[:, ~features.columns.duplicated()]
    # features.drop(columns=['dspl_descr', 'dt'], inplace=True)
    features.drop(columns=0, inplace=True)
    features = features.merge(delta_dt, on='itm_id')
    features = features.merge(qoedf, on='itm_id')
    features = features.merge(hlstd, on='itm_id')
    features = pd.concat([features, peaks], axis=1)
    features.rename(columns={'0_x': "delta_dt", '0_y': 'qoedf', 0: 'hlstd'},
                    inplace=True)
    features.reset_index(drop=True, inplace=True)

    # Drop all Na values and reset the index
    features.dropna(inplace=True)
    features = features.reset_index(drop=True)

    # Drop any item that has less than five dates
    features_dtlow = features.loc[(features.dt_count < 5) | (
            (features.dt_count < 10) & (features.delta_dt > 7.0))]
    features.drop(features_dtlow.index, inplace=True)
    features.reset_index(drop=True, inplace=True)
    print("Dropped " + str(features_dtlow.shape[0]) + " rows.")

    return features
