"""
This module contains the functions that are used for standard pre-processing
of the item level forecasting data.
"""
import pandas as pd


def drop_zeros(df: pd.DataFrame) -> pd.DataFrame:
    """
    If the item only has negative OR 0 values for the sales quantity, drop it,
    else return the original dataframe.
    :param df:
    :return:
    """
    if df['sls_qty'].max() <= 0:
        return None
    else:
        return df


# TODO: Optimize this by concatenating only once if both conditions are met
def fill_max_min(max_dt, min_dt, df: pd.DataFrame) -> pd.DataFrame:
    """
    This functions added the first and last date if they do not currently exist
    NOTE: This function, if being used in conjunction with a grouped DataFrame
    and apply may require the use of functools partial if not using a lambda
    expression
    :param max_dt: The latest date that a DataFrame should have
    :param min_dt: The minimum date that a DataFrame should have
    :param df: The DataFrame produced by a group by call
    :return: df: The same DataFrame with the dates concatenated
    """
    w_id = df.itm_id.values[0]
    w_desc = df.dspl_descr.values[0]
    if df.dt.min() > min_dt:
        df = pd.concat([df, pd.DataFrame(
            data={'itm_id': [w_id], 'dspl_descr': [w_desc], 'dt': [min_dt],
                  'sls_qty': [0], 'sls_amt': [0]})])
    if df.dt.max() < max_dt:
        df = pd.concat([df, pd.DataFrame(
            data={'itm_id': [w_id], 'dspl_descr': [w_desc], 'dt': [max_dt],
                  'sls_qty': [0], 'sls_amt': [0]})])
    return df


def fill_zeros(date_list: pd.DatetimeIndex, df: pd.DataFrame) -> pd.DataFrame:
    """
    This function psuedo-resamples the DataFrame by right merging a
    pd.DatetimeIndex onto the frame and filling NaN's with 0's then resetting
    the itm_id and dspl_descr.
    :param date_list: A pd.DatetimeIndex used to merge the DataFrame on
    :param df: The DataFrame produced by the group by call
    :return:
    """
    itm_id = df['itm_id'].max()
    dspl_descr = df['dspl_descr'].values[0]
    df = pd.merge(df, date_list, how='right', on='dt') \
        .sort_values(by='dt') \
        .reset_index(drop=True) \
        .fillna(0)
    df['itm_id'] = itm_id
    df['dspl_descr'] = dspl_descr
    return df
