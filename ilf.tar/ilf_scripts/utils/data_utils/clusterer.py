"""
This modules contains the routines for clustering the stores
"""

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.cluster import Birch
from sklearn.preprocessing import StandardScaler


def clusterer(df, features, num_tasks=100,
              desired_list=('sls_qty_mean',
                            'delta_dt',
                            'qoedf',
                            'peaks_percent',)):
    desired_features = features[[x for x in desired_list]]
    features_scaled = StandardScaler().fit_transform(desired_features.values)

    sorted_groups_sum = np.inf
    n_clusters = 5
    branch_fact = 50
    while sorted_groups_sum > 3500 or sorted_groups_sum < 1000:
        # Create the clustering model
        clusterer = Birch(n_clusters=n_clusters,
                          threshold=.1,
                          branching_factor=branch_fact)

        # Run Birch clustering on the features
        y_birch = clusterer.fit_predict(features_scaled)

        # Create a DataFrame that has the cluster_id of each item
        # as well the percentage of peaks present for that item
        clustered_data = pd.DataFrame(data=y_birch, columns=['cluster_id'])
        clustered_data['itm_id'] = features['itm_id']
        clustered_data['peaks_percent'] = features['peaks_percent']

        # TODO: Check how valid this is, maybe sort the groups by value first
        # Add the item id's to the clustered
        cluster_id = clustered_data['cluster_id']
        groups = [clustered_data[cluster_id == i]
                  for i in sorted(cluster_id.unique())]

        # Sort the groups by length
        sorted_groups = sorted(groups, key=lambda x: len(x))

        # Drop the arbitrary cluster label
        sorted_groups = [group.drop(columns=['cluster_id'])
                         for group in sorted_groups]

        # Combine the two smallest clusters and delete the 2nd one
        sorted_groups[0] = pd.concat([sorted_groups[0], sorted_groups[1]])
        del sorted_groups[1]

        # Relabel the clusters
        for label, group in enumerate(sorted_groups):
            group['cluster_id'] = label

        # Merge the cluster id onto the main DataFrame
        temp = [sorted_groups[i].merge(df, on='itm_id', how='inner')
                for i in range(len(sorted_groups))]

        # Calculate the means of each cluster
        sls_means = [[temp[i].sls_qty.mean(), i] for i in range(len(temp))]

        # Sort the groups by value, limit it to two clusters
        groups_value = sorted(sls_means, reverse=True)
        temp = [temp[groups_value[i][1]] for i in range(2)]

        # Relabel the groups by value
        for i in range(len(temp)):
            temp[i]['cluster_id'] = i

        # Reset sorted_groups to by the 'true' sorted groups
        sorted_groups = temp

        # Do iterative clustering until the ideal number of items has been
        # reached.
        sorted_groups_sum = sum([len(sorted_groups[i].itm_id.unique())
                                 for i in range(len(sorted_groups))])
        if sorted_groups_sum > 3500:
            n_clusters += 1
        elif sorted_groups_sum < 1000:
            if n_clusters >= 6:
                n_clusters -= 1
            branch_fact -= 10

    # Pass a boolean flag to say if the data has more than 30 percent peaks
    # it has many peaks (hmp)
    def has_many_peaks(df):
        if df > 0.3:
            return True
        else:
            return False

    has_many_peaks_v = np.vectorize(has_many_peaks)
    for group in sorted_groups:
        group['hmp'] = has_many_peaks_v(group.peaks_percent)
        group.drop(columns='peaks_percent', inplace=True)

    # Fix so miss clustering of items that should be considered high
    # Pull the high value items that were mis clustered into the high value item category.
    med_val_itms = sorted_groups[1].groupby(['itm_id']).mean()[['sls_qty']]
    med_val_means = med_val_itms.values

    med_val_means = med_val_means.flatten()

    # Create a 99% confidence interval for these with a students t dist
    lower_bound, upper_bound = stats.t.interval(0.99, len(med_val_means),
                                                loc=np.mean(med_val_means),
                                                scale=med_val_means.std())

    new_hv_itms = med_val_itms.loc[med_val_itms.sls_qty > upper_bound]

    # TODO: Maybe chop off stuff below the median value in this list.
    true_med_val = med_val_itms.loc[(med_val_itms.sls_qty < upper_bound)]

    hv = sorted_groups[1].loc[
        sorted_groups[1].itm_id.isin(new_hv_itms.index.values)].copy()

    hv['cluster_id'] = 0

    sorted_groups[0] = pd.concat([sorted_groups[0], hv])

    # sorted_groups[1] =
    mv = sorted_groups[1].loc[
        sorted_groups[1].itm_id.isin(true_med_val.index.values)].copy()

    # Change sorted_groups medium items to be the rest of the items
    sorted_groups[1] = mv

    # Create some number of tasks (passed as an arguments)

    group_ids = [sorted(set(group.itm_id)) for group in sorted_groups]

    task_ids = []
    for cluster, group in enumerate(group_ids):
        len_group = len(group)
        if cluster == 0:
            if len_group % 2 == 1:
                for i in range(2):
                    len_task = len_group // 2
                    task_ids.append(np.full(len_task + i, i))
            else:
                for i in range(2):
                    len_task = len_group // 2
                    task_ids.append(np.full(len_task, i))
            continue
        temp = np.zeros(len_group)
        j = 0
        len_task = len_group // num_tasks
        for i in range(len_group):
            if i == len_task * num_tasks:
                temp[i:] = j
                break
            if i % len_task == 0 and i != 0:
                j += 1
            temp[i] = j
        task_ids.append(temp)

    flatten = lambda l: [item for sublist in l for item in sublist]
    group_ids = pd.DataFrame(
        data={"itm_id": flatten(group_ids), "task_id": flatten(task_ids)})

    sorted_groups = pd.concat(sorted_groups)
    sorted_groups = sorted_groups.merge(group_ids, on='itm_id',
                                        how='inner')
    return sorted_groups
