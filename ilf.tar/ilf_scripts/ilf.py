"""
The main module for item-level-forecasting functions
"""
import io
import logging
import warnings
from functools import partial
from timeit import default_timer as time

import numpy as np
import pandas as pd
import pandas.io.sql as psqlio
import scipy.stats as st
from fbprophet import Prophet
from fbprophet.diagnostics import cross_validation
from fbprophet.diagnostics import performance_metrics
from hyperopt import hp, STATUS_OK, Trials, fmin, tpe, STATUS_FAIL
from scipy.signal import find_peaks
from sklearn.cluster import Birch
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sqlalchemy import create_engine

# if __name__ == '__main__':
#     from holidays_df import get_holidays
# else:
#     from scripts.holidays_df import get_holidays

# Set up a logger to go to sys.stdout
log = logging.getLogger('ilf')
log.setLevel(logging.DEBUG)


def db_query(store, num_tasks=100, query=None):
    """
    Query a database and get relevant information
    :param number_of_tasks: The number of tasks to generate
    :param username: Username of the database user
    :param database: The database to query
    :param query: The SQL query
    :return: None
    """

    # Pull the data from the database and save it into a data frame
    engine = create_engine('postgres://ilf@10.133.1.18:5432/ilf')
    query = """
    WITH A1 AS (
    SELECT
        itm_id,
        dspl_descr,
        dep_descr,
        dt,
        sls_qty,
        sls_amt,
        store_id
    FROM
        ilf_sales_data
    WHERE
        store_id='{store}' AND
        dt < '2019-05-01'
    ),

    B1 AS (
    SELECT DISTINCT
        itm_id,
        dt
    FROM
        A1
    GROUP BY
        itm_id, dt
    HAVING
        MAX(dt) > '2019-04-01'
    )

    SELECT DISTINCT
        b.itm_id,
        a.dspl_descr,
        a.dt,
        a.sls_qty,
        a.sls_amt
    FROM A1 AS a
    INNER JOIN B1 AS b
    ON (a.itm_id = b.itm_id);
    """.format(store=store)

    with engine.connect() as connection:
        df = psqlio.read_sql(query, connection)
    df.itm_id = pd.to_numeric(df.itm_id, downcast='integer')
    df.dt = pd.to_datetime(df.dt)

    # Pull the data that has non-zero quantity amount
    df_nz = df.copy(deep=True)
    df_nz = df_nz[df_nz.sls_qty > 0]
    itm_grouped_nz = df_nz.groupby(['itm_id'])

    def drop_zeroes(df):
        if df.sls_qty.max() <= 0:
            return None
        else:
            return df

    df = df.groupby(['itm_id'], as_index=False) \
        .apply(drop_zeroes) \
        .reset_index(drop=True)

    min_dt = df['dt'].min()
    max_dt = df['dt'].max()

    date_list = pd.date_range(min_dt,
                              periods=(max_dt - min_dt).days // 7 + 1,
                              freq='W-MON') \
        .to_series(name='dt') \
        .reset_index(drop=True)

    def fill_max_min(df):
        w_id = df.itm_id.values[0]
        w_desc = df.dspl_descr.values[0]
        df.reset_index(drop=True, inplace=True)
        if df.dt.min() > min_dt:
            df = pd.concat([df, pd.DataFrame(
                data={'itm_id': [w_id], 'dspl_descr': [w_desc], 'dt': [min_dt],
                      'sls_qty': [0], 'sls_amt': [0]})])
        if df.dt.max() < max_dt:
            df = pd.concat([df, pd.DataFrame(
                data={'itm_id': [w_id], 'dspl_descr': [w_desc], 'dt': [max_dt],
                      'sls_qty': [0], 'sls_amt': [0]})])
        return df

    def fill_zeros(df):
        df_t = df.set_index(df.dt)
        df_t = pd.merge(df, date_list, how='right', on='dt') \
            .sort_values(by='dt') \
            .reset_index(drop=True) \
            .fillna(0)
        df_t['itm_id'] = df['itm_id'].max()
        df_t['dspl_descr'] = df['dspl_descr'].values[0]
        return df_t

    df = df.groupby(by='itm_id', as_index=False) \
        .apply(fill_max_min) \
        .reset_index(drop=True)
    df = df.groupby(by='itm_id', as_index=False) \
        .apply(fill_zeros) \
        .reset_index(drop=True)

    # Get an ordered list of Item ID's
    itm_grouped = df.groupby(['itm_id'], as_index=False)

    # Extract some of the features
    itm_ids = itm_grouped.apply(lambda x: x.name).reset_index(drop=True)
    maxes = itm_grouped.max().rename(columns={'sls_qty': 'sls_qty_max',
                                              'sls_amt': 'sls_amt_max'}).reset_index(
        drop=True)
    mins = itm_grouped.min().rename(columns={'sls_qty': 'sls_qty_min',
                                             'sls_amt': 'sls_amt_min'}).reset_index(
        drop=True)
    means = itm_grouped.mean().rename(columns={'sls_qty': 'sls_qty_mean',
                                               'sls_amt': 'sls_amt_mean'}).reset_index(
        drop=True)
    stds = itm_grouped.std().rename(columns={'sls_qty': 'sls_qty_std',
                                             'sls_amt': 'sls_amt_std'}).reset_index(
        drop=True)
    medians = itm_grouped.median().rename(columns={'sls_qty': 'sls_qty_med',
                                                   'sls_amt': 'sls_amt_med'}).reset_index(
        drop=True)
    date_count = itm_grouped_nz.count().rename(
        columns={'dt': 'dt_count'}).dt_count.reset_index(drop=True)
    delta_dt = pd.DataFrame(data=itm_grouped_nz['itm_id', 'dt'].apply(
        lambda x: x.dt.diff().mean() / np.timedelta64(1, 'D'))).reset_index()

    # New features, TODO: Try and vectorize these
    # Quantile of Empiric Distribution Function
    def rm_outliers(df: pd.DataFrame) -> float:
        """
        This function returns the number of 'outliers', i.e values that fall out of a 90% confidence interval
        param: df: A pd.DataFrame that has the sales information for each date for an item
        return: int: Number of datapoints outside the confidence interval
        """
        q = df.quantile(q=[0.05, .95])
        return (len(df.loc[(df.sls_qty < q.iloc[0, 1])]) + len(
            df.loc[df.sls_qty > q.iloc[1, 1]])) / len(df)

    # Has large std function
    def has_large_std(df: pd.DataFrame) -> int:
        """
        Checks to see if the item has a large standard deviation relative to the difference of the max and min div by 2
        param: df: A pd.DataFrame that has the sales information for each date for an item
        return: Boolean 0 or 1
        """
        std_comp = (df.sls_qty.max() - df.sls_qty.min()) / 2.0
        x = []
        if df.sls_qty.std() > std_comp:
            return 1
        else:
            return 0

    # Has large number of peaks function
    def large_num_peaks(df: pd.DataFrame) -> list:
        """
        Calculates the number and the percentage of peaks relative to the datas size
        param: df: A pd.DataFrame that has the sales information for each date for an item
        return: list of integers with number of peaks, and total percentage of peaks
        """
        peaks, _ = find_peaks(df.sls_qty)
        return [len(peaks), len(peaks) / len(df)]

    # Quantile of Empirical Distribution Function
    qoedf = pd.DataFrame(data=df.groupby('itm_id').apply(rm_outliers))

    # Has large standard deviation
    hlstd = pd.DataFrame(data=df.groupby('itm_id').apply(has_large_std))

    # Number and Percentage of peaks
    peaks = pd.DataFrame(
        df.groupby('itm_id').apply(large_num_peaks).values.tolist(),
        columns=['peaks_num', 'peaks_percent'])

    # Create a features DataFrame that will hold the non-scaled features
    features = None
    features = pd.concat(
        [itm_ids, maxes, mins, medians, means, stds, date_count], axis=1)
    print([len(i) for i in
           [itm_ids, maxes, mins, medians, means, stds, date_count]])
    features = features.loc[:, ~features.columns.duplicated()]
    # features.drop(columns=['dspl_descr', 'dt'], inplace=True)
    features.drop(columns=0, inplace=True)
    features = features.merge(delta_dt, on='itm_id')
    features = features.merge(qoedf, on='itm_id')
    features = features.merge(hlstd, on='itm_id')
    features = pd.concat([features, peaks], axis=1)
    features.rename(columns={'0_x': "delta_dt", '0_y': 'qoedf', 0: 'hlstd'},
                    inplace=True)
    features.reset_index(drop=True, inplace=True)
    # print(features.isnull()[['itm_id', 'dt_count']])
    # print(len(features))
    # Drop all Na values and reset the index
    features.dropna(inplace=True)
    features = features.reset_index(drop=True)
    print(features.shape)

    # Drop any item that has less than five dates
    features_dtlow = features.loc[(features.dt_count < 5) | (
            (features.dt_count < 10) & (features.delta_dt > 7.0))]
    features.drop(features_dtlow.index, inplace=True)
    features.reset_index(drop=True, inplace=True)
    print("Dropped " + str(features_dtlow.shape[0]) + " rows.")

    # Do Standard Scaling on the columns to scale them appropriately
    # desired_features = features[['sls_qty_med', 'dt_count', 'delta_dt', 'qoedf', 'peaks_percent']]
    desired_features = features[
        ['sls_qty_mean', 'delta_dt', 'qoedf', 'peaks_percent']]

    # Scale the desired features to Standard Scale (mu=0, sigma = 1)
    features_scaled = StandardScaler().fit_transform(desired_features.values)
    features_scaled_df = pd.DataFrame(data=features_scaled)
    features_scaled_df['itm_id'] = features['itm_id']

    pca = PCA(n_components=2)
    principle_comps = pca.fit_transform(features_scaled)
    sorted_groups_sum = np.inf
    n_clusters = 5
    branch_fact = 50
    while sorted_groups_sum > 3500 or sorted_groups_sum < 1000:
        # Create the clustering model
        clusterer = Birch(n_clusters=n_clusters,
                          threshold=.1,
                          branching_factor=branch_fact)

        # Run Birch clustering on the features
        y_birch = clusterer.fit_predict(features_scaled)

        # Create a dataframe that has the classification of each item
        classified_data = pd.DataFrame(data=np.insert(principle_comps,
                                                      2,
                                                      y_birch,
                                                      axis=1),
                                       columns=[0, 1, 'cluster_id'])
        classified_data['itm_id'] = features['itm_id']
        classified_data['peaks_percent'] = features['peaks_percent']
        cluster_id = classified_data['cluster_id']
        # Add the item id's to the classified features
        groups = [classified_data.loc[cluster_id == i]
                  for i in sorted(set(cluster_id.values))]
        sorted_groups = sorted(groups, key=lambda x: len(x))
        sorted_groups = [group.drop(columns=['cluster_id']) for group in
                         sorted_groups]

        sorted_groups[0] = pd.concat([sorted_groups[0], sorted_groups[1]])
        del sorted_groups[1]

        for label, group in enumerate(sorted_groups):
            group['cluster_id'] = label

        temp = [sorted_groups[i].merge(df, on='itm_id', how='inner') for i in
                range(4)]
        sls_means = [[temp[i].sls_qty.mean(), i] for i in range(len(temp))]
        groups_value = sorted(sls_means, reverse=True)
        temp = [temp[groups_value[i][1]] for i in range(2)]

        for i in range(len(temp)):
            temp[i]['cluster_id'] = i

        sorted_groups = temp

        sorted_groups_sum = sum([len(set(sorted_groups[i].itm_id))
                                 for i in range(len(sorted_groups))])
        log.debug("Sorted_groups_sum has a value of %s",
                  str(sorted_groups_sum))
        if sorted_groups_sum > 3500:
            n_clusters += 1
        elif sorted_groups_sum < 1000:
            if n_clusters >= 6:
                n_clusters -= 1
            branch_fact -= 10

    # Pass a boolean flag to say if the data has more than 30 percent peaks
    # it has many peaks (hmp)
    def has_many_peaks(df):
        if df > 0.3:
            return True
        else:
            return False

    has_many_peaks_v = np.vectorize(has_many_peaks)
    for group in sorted_groups:
        group['hmp'] = has_many_peaks_v(group.peaks_percent)
        group.drop(columns='peaks_percent', inplace=True)

    # Fix so miss clustering of items that should be considered high
    # Pull the high value items that were mis clustered into the high value item category.
    med_val_itms = sorted_groups[1].groupby(['itm_id']).mean()[['sls_qty']]
    med_val_means = med_val_itms.values

    med_val_means = med_val_means.flatten()

    # Create a 99% confidence interval for these
    lower_bound, upper_bound = st.t.interval(0.99, len(med_val_means),
                                             loc=np.mean(med_val_means),
                                             scale=med_val_means.std())

    new_hv_itms = med_val_itms.loc[med_val_itms.sls_qty > upper_bound]

    # TODO: Maybe chop off stuff below the median value in this list.
    true_med_val = med_val_itms.loc[(med_val_itms.sls_qty < upper_bound)]

    hv = sorted_groups[1].loc[
        sorted_groups[1].itm_id.isin(new_hv_itms.index.values)].copy()

    hv['cluster_id'] = 0

    sorted_groups[0] = pd.concat([sorted_groups[0], hv])

    # sorted_groups[1] =
    mv = sorted_groups[1].loc[
        sorted_groups[1].itm_id.isin(true_med_val.index.values)].copy()

    # Change sorted_groups medium items to be the rest of the items
    sorted_groups[1] = mv

    # Create some number of tasks (passed as an arguments)

    group_ids = [sorted(set(group.itm_id)) for group in sorted_groups]

    task_ids = []
    for cluster, group in enumerate(group_ids):
        len_group = len(group)
        if cluster == 0:
            task_ids.append(np.zeros(len_group))
            continue
        temp = np.zeros(len_group)
        j = 0
        len_task = len_group // num_tasks
        for i in range(len_group):
            if i == len_task * num_tasks:
                temp[i:] = j
                break
            if i % len_task == 0 and i != 0:
                j += 1
            temp[i] = j
        task_ids.append(temp)

    flatten = lambda l: [item for sublist in l for item in sublist]
    group_ids = pd.DataFrame(
        data={"itm_id": flatten(group_ids), "task_id": flatten(task_ids)})

    sorted_groups = pd.concat(sorted_groups)
    sorted_groups = sorted_groups.merge(group_ids, on='itm_id', how='inner')

    work_data = sorted_groups.drop(
        columns=[0, 1, 'dspl_descr', 'sls_amt']).reset_index(drop=True)

    work_data['store_id'] = store

    work_data.head(0).to_sql('work_table', engine, if_exists="append",
                             index=False)
    # Understand the code
    conn = engine.raw_connection()
    cur = conn.cursor()
    output = io.StringIO()
    work_data.to_csv(output, sep='\t', header=False, index=False)
    output.seek(0)
    # contents = output.getvalue()
    cur.copy_from(output, 'work_table', null="")  # null values become ''
    conn.commit()
    conn.close()


def data_split(df, start_date, use_date_till, end_date):
    """
    Create the training and testing data
    param: df: The dataframe with the data to split
    param: start_date: The date to start in the training data
    param: use_date_till: The date to use for training data, and the date
                          which the test data begins
    param: end_date: The date which is forecasted.
    """

    start_date = pd.Timestamp(start_date)
    use_date_till = pd.Timestamp(use_date_till)

    # Create the training data for each item
    train_ds = df.loc[(df.dt >= start_date)
                      & (df.dt <= use_date_till)].dt
    train_y = df.loc[(df.dt >= start_date)
                     & (df.dt <= use_date_till)].sls_qty
    train_data = pd.DataFrame({
        'ds': train_ds,
        'y': train_y
    }).sort_values(by='ds').reset_index(drop=True)

    # Create the test data
    test_ds = df.loc[(df.dt > use_date_till)
                     & (df.dt <= end_date)].dt
    test_y = df.loc[(df.dt > use_date_till)
                    & (df.dt <= end_date)].sls_qty
    test_data = pd.DataFrame({
        "ds": test_ds,
        "y": test_y
    }).reset_index(drop=True)

    return train_data, test_data


def error_log(err, engine, itm_id=None, len_df=None, end_date=None):
    """
    Logs errors based on an err id provided
    param: err: The error code
    """
    if err == 0:
        log.debug('Itm_id: %s skipped due to insufficient data', itm_id)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [0]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 1:
        log.debug('Itm_id: %s skipped due to insufficient data', itm_id)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [1]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 2:
        log.debug('Itm_id: %s skipped due to insufficient number \\\
                    of y values', itm_id)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [2]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 3:
        log.debug('Test date %s does not exists', end_date)
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [3]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)
    elif err == 4:
        log.debug('Hyperopt failed to have any values in its sequence')
        pd.DataFrame({'itm_id': [itm_id],
                      'length': [len_df],
                      'error': [4]}).to_sql('skipped',
                                            engine,
                                            if_exists="append",
                                            index=False)


def mape(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    if np.count_nonzero(y_true) > 0:
        return abs(np.mean(np.abs((y_true - y_pred) / y_true)) * 100)
    return -100


def get_hp_space():
    temp = {
        "holidays_prior_scale": hp.uniform("holidays_prior_scale", 5.0, 10.0),
        "changepoint_prior_scale": hp.uniform("changepoint_prior_scale", 0.001,
                                              0.7),
        "yearly_seasonality": hp.quniform("yearly_seasonality", 5.0, 10.0, 1),
        "seasonality_prior_scale": hp.uniform("seasonality_prior_scale", 5.0,
                                              15.0),
        # "seasonality_mode": hp.choice("seasonality_mode", ('additive',
        #                                                    'multiplicative')),
        # "weekly_seasonality": hp.quniform("weekly_seasonality", 1, 10, 1),
    }
    return temp


def get_hp_objective(train_data, params):
    """
    Returns the average MAPE from Cross Validation
    values from given hyper parameters, allow for a failure in prophet to
    occur from negative values
    """
    try:
        start_time = time()
        # Create the model m with given hyperparameters
        train_model = Prophet(daily_seasonality=False,
                              **params)
        # Add built in holidays to the model
        train_model.add_country_holidays(country_name='US')

        # Fit the model
        train_model.fit(train_data)

        # Set the initial amount of training data to half
        init_train_data = round(
            (.1 * np.random.randn() + 0.60) * len(train_data))
        # Perform cross validation and extract performance metrics
        remaining_weeks = round(len(train_data) - init_train_data)
        # Initial data is %50 of the total training dat
        initial = str(init_train_data) + " W"
        period = str(round(remaining_weeks // np.random.randint(3, 8))) + " W"
        horizon = '1 W'
        df_cv = cross_validation(train_model,
                                 initial=initial,
                                 period=period,
                                 horizon=horizon)
        print(df_cv)
        # Return the loss as the average MAPE of the CV runs
        df_p = performance_metrics(df_cv)

        total_time = time() - start_time
        log.debug("Hyperopt took %s seconds", total_time)
        return {'loss': np.mean(df_p['mape']),
                'status': STATUS_OK,
                'eval_time': time}
    except ValueError:
        log.debug(ValueError)
        return {'status': STATUS_FAIL}
    except RuntimeError:
        log.debug("Runtime Error, check logs")
        return {'status': STATUS_FAIL}


def get_fake_holidays(df, start_date, end_date):
    peaks, peak_heights = find_peaks(-df['sls_qty'])

    data_part = df['sls_qty'][peaks[0]:peaks[-1]]
    time_part = df['dt'][peaks[0]:peaks[-1]]

    index_date = time_part.index[time_part != 0].values
    baseline = np.interp(index_date, peaks, df['sls_qty'][peaks])
    data_without_baseline = data_part - baseline

    data_without_baseline = data_without_baseline.reset_index(drop=True)
    loc_neg = np.where(data_without_baseline < 0)
    data_without_baseline[loc_neg[0]] = 0

    time_part_index_new = time_part.reset_index(drop=True)
    # extract year information and get the end location of each year
    time_part_0 = pd.DatetimeIndex(time_part_index_new).year
    loc = [0, np.where(time_part_0 == 2017)[0].max() + 1,
           np.where(time_part_0 == 2018)[0].max() + 1, len(time_part_0)]
    # loc
    for j in range(3):  # 3 years
        date_name = pd.DataFrame(data={
            'dt': time_part_index_new[loc[j]:loc[j + 1]].reset_index(
                drop=True),
            'sls_qty': data_without_baseline[loc[j]:loc[j + 1]].reset_index(
                drop=True)})
        date_name['dt'] = pd.to_datetime(date_name['dt'])
        date_name['dt'] = pd.to_datetime(date_name['dt'].dt.strftime('%m-%d'),
                                         format='%m-%d')
        if j == 0:
            new_data_all_date = date_name
        else:
            new_data_all_date = pd.merge_ordered(new_data_all_date, date_name,
                                                 on='dt')

    new_data_all_date.columns = ('dt', 'qty2017', 'qty2018', 'qty2019')
    new_data_all_date = new_data_all_date.fillna(0)

    mean_data = (new_data_all_date['qty2017'] + new_data_all_date['qty2018'] +
                 new_data_all_date['qty2019']) / 3
    new_loc = np.where(mean_data > 0.5 * mean_data.max())

    # Find data driven holidays in each year & Calculate the mean
    # and std of normal distribution
    fake_holiday = []
    df_list = []
    for i in range(3):
        fake_holiday_0 = new_data_all_date['dt'][new_loc[0]].apply(
            lambda x: x.replace(year=2017 + i))
        fake_holiday = fake_holiday + fake_holiday_0.tolist()
        df_list = df_list + new_data_all_date['qty201' + str(i + 7)][
            new_loc[0]].tolist()  # Amplitude of spikes

    df_list = list(filter(lambda x: x > 0, df_list))

    data_driven_mean = np.mean(df_list)
    data_driven_std = np.std(df_list)

    # # data_driven_holidays = []
    # #
    # # for i, date in enumerate(fake_holiday):
    # #     data_driven_holidays.append({
    # #         'holiday': 'holiday'+str(i),
    # #         'ds': date
    # #     })
    # # data_driven_holidays = pd.DataFrame(data_driven_holidays)
    # # data_driven_holidays = data_driven_holidays.loc[
    # #     data_driven_holidays['ds'] >= start_date]
    # # data_driven_holidays.reset_index(drop=True, inplace=True)
    #
    # return data_driven_holidays
    return fake_holiday


def run_prophet(task_number, cluster_id, store_id,
                use_provided_dates=False,
                start_date=None, end_date=None, use_date_till=None,
                max_evals=10, use_hyperopt=True):
    """
    Run the prophet algorithm, for item level forecasts
    Note on error codes in the skipped table:
        0: length of the database was less than or equal to 3
        1: last sale was not within 4 weeks of most recent sale
        2: less than 3 sales data points were present and would crash prophet
    :param task_number: The task id pass to pull from the database
    :param start_date: The date to start forecasting
    :param end_date: The date to end testing
    :param use_date_till: The date to end training training
    :return:
    """
    # Disable output from prophet and deprecation waarnings etc
    # logging.getLogger('fbprophet').setLevel(logging.ERROR)
    # logging.getLogger('hyperopt').setLevel(logging.ERROR)
    warnings.simplefilter("ignore", DeprecationWarning)
    warnings.simplefilter("ignore", FutureWarning, )
    log.debug("Running prophet")
    module_start_time = time()

    # Define the 'engine' used to interact with the database
    engine = create_engine('postgresql://ilf@10.133.1.18:5432/ilf', echo=True)

    # Execute the query and save the results as a pandas database
    query = """
            select itm_id, dt, sls_qty, cluster_id, store_id, hmp from work_table
            where task_id={} and cluster_id={} and store_id='{}'
            """.format(task_number, cluster_id, store_id)
    start_time = time()
    df_raw = pd.read_sql_query(query, engine)
    total_time = time() - start_time
    log.debug('Time spent extracting task_id %s, %s', task_number, total_time)

    df_grouped = df_raw.groupby('itm_id', sort=False, as_index=False)

    df_grouped = [group for _, group in df_grouped]

    log.debug("Total number of items to forecast %s", len(df_grouped))

    cluster_id = df_grouped[0]["cluster_id"].values[0]
    store_id = df_grouped[0]["store_id"].values[0]

    log.debug("Store id %s, cluster_id %s", store_id, cluster_id)

    for df in df_grouped:
        start_time = time()

        df.reset_index(drop=True, inplace=True)

        # Define some variables about the data
        len_df = len(df)
        itm_id = df.itm_id.values[0]
        hmp = df.hmp.values[0]
        log.debug("Started Forecasting: %s", itm_id)
        #        applicable_holidays = get_holidays(dep_descr)

        # Check if the data present is at least 3 dates,
        # if not continue to next item
        # Error Code: 0
        if len_df <= 3:
            error_log(0, engine, itm_id, len_df)
            continue

        # Set the start_date, end_date, and use_date_till variables dependent
        # on idividual data
        if not use_provided_dates:
            start_date = df.dt.iat[0]
            end_date = df.dt.iat[-2]
            use_date_till = df.dt.iat[-3]

        # Set the number of dats to forecast out to
        forecast_gap = (end_date - use_date_till).days // 7

        # Check if the last sale was within 4 weeks of most recent sale,
        # if not continue to next item
        if forecast_gap > 4:
            error_log(1, engine, itm_id, len_df)
            continue

        train_data, test_data = data_split(df, start_date,
                                           use_date_till, end_date)

        # Check if total number of not NULL sales in the training data is less
        # or equal to 2 to prevent prophet from crashing, if so continue to
        # next item
        if train_data[train_data['y'].notnull()].shape[0] <= 2:
            error_log(2, engine, itm_id, len_df)
            continue

        #######################################################################
        #                           Pull out the peaks                        #
        #######################################################################
        # If the item is flagged as having many peaks, remove them
        if hmp:
            fake_holidays = get_fake_holidays(df, start_date, end_date)

            # Remove the peaks from the training data.
            train_data = train_data[~train_data.ds.isin(fake_holidays)]
        #######################################################################
        #                           Begin Hyperopt                            #
        #######################################################################
        if cluster_id == 0 or use_hyperopt:
            # Define the objective function partially by passing it the
            # training data but not the parameters
            objective = partial(get_hp_objective, train_data)

            # Define the space for hyperopt to be searching in
            space = get_hp_space()

            # Define the Trials for the given itm_id
            # TODO: Make this database friendly by providing a unique
            #  key for every item
            trials = Trials()

            # Run fmin and save the best results to best
            try:
                best = fmin(fn=objective,
                            space=space,
                            algo=tpe.suggest,
                            max_evals=max_evals,
                            trials=trials)
            except ValueError:
                log.debug(ValueError)
                error_log(4, engine, itm_id, len_df)
                continue
        else:
            best = {'daily_seasonality': False,
                    'weekly_seasonality': False,
                    'yearly_seasonality': True}
        #######################################################################
        #                           Begin Prophet Model                       #
        #######################################################################

        # Begin forecasting of the item
        log.debug('Forecasting itm_id: %s', itm_id)
        model = Prophet(**best)
        model.add_country_holidays(country_name='US')
        model.fit(train_data)
        # Forecast a week into the future
        future = model.make_future_dataframe(periods=forecast_gap,
                                             freq='W-MON')
        forecast = model.predict(future)

        total_time = time() - start_time
        log.debug('Finished forecasting for itm_id: %s in %s',
                  itm_id,
                  total_time)

        yhat = forecast.loc[(forecast.ds > use_date_till)
                            & (forecast.ds <= end_date)] \
            .yhat \
            .reset_index(drop=True)

        of = pd.merge(test_data, yhat,
                      left_index=True,
                      right_index=True)

        # Write to the log if the out frame is empty
        if of.empty:
            error_log(3, engine, itm_id, len_df, end_date)
            continue

        # Calculate accuracy for the last 7 days from the of
        y_true = of.loc[(of.ds > use_date_till) & (of.ds <= end_date)].y
        y_pred = of.loc[(of.ds > use_date_till) & (of.ds <= end_date)].yhat
        accuracy = 100.0 - mape(y_true, y_pred)  # e.g 1 - the percent error

        of['accuracy'] = accuracy
        of['itm_id'] = itm_id
        of['store_id'] = store_id
        of['cluster_id'] = cluster_id
        of.reset_index(drop=True, inplace=True)
        log.debug('Writing to data frame')
        start_time = time()
        # of.to_sql('forecasts',
        #           engine,
        #           if_exists="append",
        #           eindex=False)
        total_time = time() - start_time
        log.debug('Writing forecast of itm_id: %s to DB took %s',
                  itm_id,
                  total_time)
        print(of)
    total_module_time = time() - module_start_time
    log.debug('Entire task of %s items took %s',
              len(df_grouped),
              total_module_time)


if __name__ == '__main__':
    # db_query('FrontOff009', num_tasks=16)
    run_prophet(0, 0, 'FrontOff241', max_evals=4)
