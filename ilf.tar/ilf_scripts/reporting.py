import pandas as pd
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from sqlalchemy import create_engine

wb = Workbook()

ws = wb.active

ws.title = "test title"

engine = create_engine('postgresql://ilf@10.133.1.18:5432/ilf', echo=False)

# Execute the query and save the results as a pandas database
query = """
        select itm_id, y, yhat, accuracy, cluster_id, store_id from forecasts
        where cluster_id={} and store_id='{}'
        """.format(0, 'FrontOff001')
df = pd.read_sql_query(query, engine)

for row in dataframe_to_rows(df, index=False, header=True):
    ws.append(row)

for cell in ws[1]:
    cell.style = 'Pandas'

ws['J1'] = "Average Accuracy"
ws['J2'] = df.accuracy.mean()

poor_items = df.loc[df.accuracy < 0]
ws.append(["Very Poor Performing Forecasts"])
for row in dataframe_to_rows(poor_items, index=False, header=True):
    ws.append(row)

wb.save("test_data_dump.xlsx")
