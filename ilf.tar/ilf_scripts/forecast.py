# Set the openblas library to use one thread
import os

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

import logging
import warnings
from functools import partial
from pprint import pprint
from timeit import default_timer as time

import pandas as pd
from hyperopt import fmin, tpe, Trials, space_eval
from sqlalchemy import create_engine

from ilf_scripts.utils.forecasting_utils import models
from ilf_scripts.utils.forecasting_utils.error_logging import error_log
from ilf_scripts.utils.forecasting_utils.hyperopt_funcs import mape, \
    model_objective, model_selection_space, mae
from ilf_scripts.utils.forecasting_utils.train_test_split import \
    train_test_split

log = logging.getLogger('ilf')
log.setLevel(logging.DEBUG)


def forecast(task_number, cluster_id, store_id,
             use_provided_dates=False,
             start_date=None, end_date=None, use_date_till=None,
             max_evals=10, use_hyperopt=True, write_to_db=True):
    """
    This is the main method that runs the forecast.
    :param task_number: The task number assigned to each itm_id
    :param cluster_id: The cluster number assigned to each itm_id
    :param store_id: The store id of the which the itm_id belongs to
    :param use_provided_dates: If we should use the provided dates or not
    :param start_date: The earliest date
    :param end_date: The last date for test_data
    :param use_date_till: The date to use training data up to
    :param max_evals: The maximum number of evaluations for hyperopt
    :param use_hyperopt: If we are using hyperopt or not
    :param write_to_db: Debugging parameter to write forecasts to database
    :return: None, writes results of the forecast to a database
    """

    # Ignore warnings from all the models and packages
    warnings.simplefilter("ignore", DeprecationWarning)
    warnings.simplefilter("ignore", FutureWarning, )

    warnings.filterwarnings('ignore')

    log.debug("Running Forecasting")
    module_start_time = time()

    # Define the 'engine' used to interact with the database
    engine = create_engine('postgresql://ilf@10.133.1.18:5432/ilf', echo=False)

    # Execute the query and save the results as a pandas database
    query = """
            select itm_id, dt, sls_qty, cluster_id, store_id, hmp 
            from work_table
            where task_id={} and cluster_id={} and store_id='{}'
            """.format(task_number, cluster_id, store_id)

    start = time()
    df_raw = pd.read_sql_query(query, engine)
    log.debug('Time spent extracting cluster id %s task_id %s, %s',
              cluster_id, task_number, str(time() - start))

    # Group the raw data by itm_id, keep it unsorted
    df_grouped = df_raw.groupby('itm_id', sort=False, as_index=False)

    # Turn the grouped DataFrame in a list of DataFrames
    df_grouped = [group for _, group in df_grouped]
    log.debug("Total number of items to forecast %s", len(df_grouped))

    # Save the common information about the store and clusters between all
    # the items
    cluster_id = df_grouped[0]["cluster_id"].values[0]
    store_id = df_grouped[0]["store_id"].values[0]

    log.debug("Store id %s, cluster_id %s", store_id, cluster_id)
    log.debug("Starting forecasting of %s items", len(df_grouped))

    # Begin forecasting for each individual item
    for df in df_grouped:
        start = time()

        # Reset the index of the DataFrame
        df.reset_index(drop=True, inplace=True)

        # Define some local variables about the data
        len_df = len(df)
        itm_id = df.itm_id.values[0]
        hmp = df.hmp.values[0]
        log.debug("Started Forecasting: %s", itm_id)

        # Check if the data present is at least 3 dates,
        # if not continue to next item
        # Error Code: 0
        if len_df <= 3:
            error_log(0, engine, itm_id, len_df)
            continue

        # Set the start_date, end_date, and use_date_till variables dependent
        # on individual data
        if not use_provided_dates:
            start_date = df.dt.iat[0]
            end_date = df.dt.iat[-2]
            use_date_till = df.dt.iat[-3]

        # Set the number of dats to forecast out to
        forecast_gap = (end_date - use_date_till).days // 7

        # Check if the last sale was within 4 weeks of most recent sale,
        # if not continue to next item
        if forecast_gap > 4:
            error_log(1, engine, itm_id, len_df)
            continue

        # Split the training and testing data based on dates provided
        train_data, test_data = train_test_split(df,
                                                 start_date,
                                                 use_date_till,
                                                 end_date)

        # Check if total number of not NULL sales in the training data is less
        # or equal to 2 to prevent prophet from crashing, if so continue to
        # next item
        if train_data[train_data['y'].notnull()].shape[0] <= 2:
            error_log(2, engine, itm_id, len_df)
            continue

        # Remove peaks
        # If the item is flagged as having many peaks, remove them
        # TODO: Add a check here to see if the date we are forecasting is
        #       one of these peaks. Also check to see if interpolating values
        #       is a good idea.

        # Run hyperopt if applicable
        if use_hyperopt:
            trails = Trials()
            # Define the objective function partially by passing it the
            # training data but not the parameters
            # objective = partial(get_hp_objective, train_data)
            objective = partial(model_objective,
                                train_data, forecast_gap,
                                use_date_till,
                                end_date,
                                hmp)

            # Define the space for hyperopt to be searching in
            space = model_selection_space()

            # Run fmin and save the best results to best
            try:
                # with suppress_stdout_stderr():
                best = fmin(fn=objective,
                            space=space,
                            algo=tpe.suggest,
                            max_evals=max_evals,
                            trials=trails,
                            show_progressbar=False)
            except ValueError:
                print(ValueError)
                error_log(4, engine, itm_id, len_df)
                continue
        # If not using hyperopt default to using fbprophet with default
        # hyper parameters
        else:
            best = {'type': 'fbprophet',
                    'daily_seasonality': False,
                    'weekly_seasonality': False,
                    'yearly_seasonality': True}

        # Begin forecasting of the item
        log.debug('Forecasting itm_id: %s', itm_id)

        if 'space' in locals():
            best = space_eval(space, best)
        print(best)
        m = models.model(best['type']).get_model()
        m.set_train_data(train_data,
                         forecast_gap,
                         use_date_till,
                         end_date,
                         hmp)
        m.set_parameters(best, holidays=True)
        forecast = m.fit_predict()

        log.debug('Finished forecasting for itm_id: %s in %s',
                  itm_id,
                  time() - start)

        yhat = forecast.loc[(forecast.ds > use_date_till)
                            & (forecast.ds <= end_date)] \
            [['yhat', 'yhat_lower', 'yhat_upper']] \
            .reset_index(drop=True)

        of = pd.merge(test_data, yhat, left_index=True, right_index=True)

        # Write to the log if the out frame is empty
        if of.empty:
            error_log(3, engine, itm_id, len_df, end_date)
            continue

        # Calculate accuracy for the last 7 days from the of
        y_true = of.loc[(of.ds > use_date_till) & (of.ds <= end_date)].y
        y_pred = of.loc[(of.ds > use_date_till) & (of.ds <= end_date)].yhat

        of['mape'] = 100.0 - mape(y_true, y_pred) * 100
        of['mae'] = mae(y_true, y_pred)
        of['itm_id'] = itm_id
        of['store_id'] = store_id
        of['cluster_id'] = cluster_id
        of['hyperopt'] = use_hyperopt
        of['model'] = best['type']
        of['hyper_params'] = str(list(best.items()))
        of.reset_index(drop=True, inplace=True)
        log.debug('Writing to data frame')
        start_time = time()
        print(of)
        if write_to_db:
            of.to_sql('forecasts',
                      engine,
                      if_exists="append",
                      index=False)
        total_time = time() - start_time
        log.debug(
            'Writing forecast of itm_id: %s to DB took %s with accuracy %s',
            str(itm_id),
            str(total_time),
            str(of['mape'].values[0]))

        pprint(of)
    total_module_time = time() - module_start_time
    log.debug('Entire task of %s items took %s',
              len(df_grouped),
              str(total_module_time))


if __name__ == '__main__':
    forecast(0, 0, 'FrontOff001', max_evals=2, use_hyperopt=True)
